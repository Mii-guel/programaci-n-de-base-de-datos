SET SERVEROUTPUT ON;

DECLARE
    -- 1. CURSOR EXPLÍCITO
    CURSOR cur_transac IS
        SELECT 
            t.nro_tarjeta,
            t.nro_transaccion,
            t.fecha_transaccion,
            t.monto_total_transaccion,
            tp.nombre_tptran_tarjeta as tipo,
            c.numrun,
            c.dvrun
        FROM TRANSACCION_TARJETA_CLIENTE t
        JOIN TARJETA_CLIENTE tc ON t.nro_tarjeta = tc.nro_tarjeta
        JOIN CLIENTE c ON tc.numrun = c.numrun
        JOIN TIPO_TRANSACCION_TARJETA tp ON t.cod_tptran_tarjeta = tp.cod_tptran_tarjeta;

    -- Variables
    v_porc_sbif      NUMBER;
    v_monto_sbif     NUMBER;
    v_fecha_venc     DATE;
    v_cont           NUMBER := 0;

BEGIN
    -- 2. LIMPIEZA
    EXECUTE IMMEDIATE 'TRUNCATE TABLE DETALLE_APORTE_SBIF';
    EXECUTE IMMEDIATE 'TRUNCATE TABLE RESUMEN_APORTE_SBIF';
    EXECUTE IMMEDIATE 'TRUNCATE TABLE BALANCE_ANUAL_DETALLE_TRANSAC';

    -- 3. PROCESAMIENTO
    FOR reg IN cur_transac LOOP
        
        -- A. Lógica Aporte SBIF
        v_monto_sbif := 0; 
        IF reg.tipo IN ('Avance en Efectivo', 'Súper Avance en Efectivo') THEN
            BEGIN
                SELECT (porc_aporte_sbif / 100)
                INTO v_porc_sbif
                FROM TRAMO_APORTE_SBIF
                WHERE reg.monto_total_transaccion BETWEEN tramo_inf_av_sav AND tramo_sup_av_sav;

                v_monto_sbif := ROUND(reg.monto_total_transaccion * v_porc_sbif);

                INSERT INTO DETALLE_APORTE_SBIF (
                    numrun, dvrun, nro_tarjeta, nro_transaccion, 
                    fecha_transaccion, tipo_transaccion, monto_transaccion, aporte_sbif
                ) VALUES (
                    reg.numrun, reg.dvrun, reg.nro_tarjeta, reg.nro_transaccion,
                    reg.fecha_transaccion, reg.tipo, reg.monto_total_transaccion, v_monto_sbif
                );
            EXCEPTION
                WHEN NO_DATA_FOUND THEN v_monto_sbif := 0;
            END;
        END IF;

        -- B. Obtener Fecha de Vencimiento
        SELECT NVL(MAX(fecha_venc_cuota), reg.fecha_transaccion)
        INTO v_fecha_venc
        FROM CUOTA_TRANSAC_TARJETA_CLIENTE
        WHERE nro_transaccion = reg.nro_transaccion AND nro_tarjeta = reg.nro_tarjeta;

        -- C. INSERCIÓN EN BALANCE (Con todas las columnas de tu tabla)
        INSERT INTO BALANCE_ANUAL_DETALLE_TRANSAC (
            MES_ANNO,
            RUN_CLIENTE,
            NRO_TARJETA, -- CORREGIDO: De NRO_TAR_ETA a NRO_TARJETA
            FECHA_TRANSACCION,
            NRO_TRANSACCION,
            TIPO_TRANSACCION,
            MONTO_TOTAL_TRANSACCION,
            FECHA_VENC_ULT_CUOTA,
            NRO_CUOTA_PAGADA,
            FECHA_VENC_CUOTA,
            VALOR_CUOTA,
            FECHA_PAGO,
            MONTO_PAGADO,
            DEUDA_PAGO_CUOTA,
            DEUDA_POR_PAGAR
        ) VALUES (
            TO_CHAR(reg.fecha_transaccion, 'MMYYYY'),
            reg.numrun || '-' || reg.dvrun,
            reg.nro_tarjeta,
            reg.fecha_transaccion,
            reg.nro_transaccion,
            reg.tipo,
            reg.monto_total_transaccion,
            v_fecha_venc,
            0,                 -- NRO_CUOTA_PAGADA (Default 0)
            v_fecha_venc,      -- FECHA_VENC_CUOTA
            0,                 -- VALOR_CUOTA (Default 0)
            NULL,              -- FECHA_PAGO (Permite NULL usualmente)
            0,                 -- MONTO_PAGADO
            0,                 -- DEUDA_PAGO_CUOTA
            reg.monto_total_transaccion -- DEUDA_POR_PAGAR
        );

        v_cont := v_cont + 1;
    END LOOP;

    -- 4. RESUMEN FINAL
    INSERT INTO RESUMEN_APORTE_SBIF (mes_anno, tipo_transaccion, monto_total_transacciones, aporte_total_abif)
    SELECT 
        TO_CHAR(fecha_transaccion, 'MMYYYY'), 
        tipo_transaccion, 
        SUM(monto_transaccion), 
        SUM(aporte_sbif)
    FROM DETALLE_APORTE_SBIF
    GROUP BY TO_CHAR(fecha_transaccion, 'MMYYYY'), tipo_transaccion;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('>>> PROCESO SEMANA 5 FINALIZADO CON EXITO <<<');
    DBMS_OUTPUT.PUT_LINE('Registros procesados: ' || v_cont);

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('ERROR INESPERADO: ' || SQLERRM);
END;
/